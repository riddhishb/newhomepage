﻿Free Responsive HTML5 Template

Bluez free responsive bootstrap web template is developed for multi-purpose use with an awesome flat design coded with clean html5, and this template built with valid HTML5 & CSS3. It's based on latest Bootstrap framework 3.3.1 fully responsive web compatible with multi browser and devices. This template can be used for multi-purpose needs like business, consultancy, agency, personal portfolio, profile, mobile website and start-up company.

Theme Details:
-------------
Twitter Bootstrap 3.3.1
Clean & Developer-friendly HTML5 and CSS3 code
100% Responsive Layout Design 
Multi-purpose theme
Google Fonts Support
Font Awesome 
Smooth Scrolling 
Fully Customizable
Contact Form
Drop-down Menu


Credits :
-------
=> Design and developed: "themesplay"  http://themesplay.com
=> Photos used in template: **Unsplash** - http://unsplash.com, http://risewall.com/home-business-team-wallpapers.html
=> For more free web themes: http://themesplay.com
=> Framework : http://getbootstrap.com

 
License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

- You are allowed to use all files for both personal and commercial projects.

- If you use/modify the resources in your projects,we’d appreciate a linkback to this site.

- You do not have rights to redistribute,resell or offer files from this site to any third party
 
- If you have any question,feel free to contact us at themesplay@gmail.com

- All images user here is for demo purpose only, we are not responsible for any copyrights.
 
